package com.example.myapplication;

public class MyThread implements Runnable {

    @Override
    public void run() {

    }
}
